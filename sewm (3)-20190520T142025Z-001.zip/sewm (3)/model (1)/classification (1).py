from sklearn import preprocessing, decomposition, svm, cross_validation
#from sklearn.model_selection import  cross_validate
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import *
import random
import numpy as np
import matplotlib.pylab as pl
import pandas as pd




clfs = {'RF': RandomForestClassifier(n_estimators=50, n_jobs=-1),
        'ET': ExtraTreesClassifier(n_estimators=10, n_jobs=-1, criterion='entropy'),
        'AB': AdaBoostClassifier(DecisionTreeClassifier(max_depth=1), algorithm="SAMME", n_estimators=200),
        'LR': LogisticRegression(penalty='l1', C=1e5),
        'SVM': svm.SVC(kernel='linear', probability=True, random_state=0),
        'GB': GradientBoostingClassifier(learning_rate=0.05, subsample=0.5, max_depth=6, n_estimators=10),
        'NB': GaussianNB(),
        'DT': DecisionTreeClassifier()
        }


class Model:

    def __init__(self, dataSet, dependentVar, doPCA=True, nComponents=10):
     
       
        for i,tp in enumerate(dataSet.dtypes):
            if tp == 'object': 
                print 'Encoding feature \"' + dataSet.columns[i] + '\" ...'
                print 'Old dataset shape: ' + str(dataSet.shape)
                temp = pd.get_dummies(dataSet[dataSet.columns[i]],prefix=dataSet.columns[i])
                dataSet = pd.concat([dataSet,temp],axis=1).drop(dataSet.columns[i],axis=1)
                print 'New dataset shape: ' + str(dataSet.shape)
               
        y = dataSet.loc[:,dependentVar]

       
        labels = preprocessing.LabelEncoder().fit_transform(y)

       
        X = dataSet.drop(dependentVar,1).values
                               
        X = preprocessing.StandardScaler().fit(X).transform(X)
        
        
        if doPCA:
            print 'Performing PCA'
            estimator = decomposition.PCA(n_components=nComponents)
            X = estimator.fit_transform(X)
            print 'Shape of dataset after PCA: ' + str(X.shape) + '\n'
            
       
        self.dataset = X
        self.labels = labels
        self.students = dataSet.index


    def subsample(self, x, y, ix, subsample_ratio=1.0):
       

        
        indexes_0 = [item for item in ix if y[item] == 0]
        indexes_1 = [item for item in ix if y[item] == 1]

        
        sample_length = int(len(indexes_1)*subsample_ratio)
        sample_indexes = random.sample(indexes_0, sample_length) + indexes_1

        return sample_indexes


   

    def SMOTE(self, T, N, k, h = 1.0):
        
        n_minority_samples, n_features = T.shape
        
        if N < 100:
           
            N = 100
            pass

        if (N % 100) != 0:
            raise ValueError("N must be < 100 or multiple of 100")
        
        N = N/100
        n_synthetic_samples = N * n_minority_samples
        S = np.zeros(shape=(n_synthetic_samples, n_features))
        
       
        neigh = NearestNeighbors(n_neighbors = k)
        neigh.fit(T)
        
       
        for i in xrange(n_minority_samples):
            nn = neigh.kneighbors(T[i], return_distance=False)
            for n in xrange(N):
                nn_index = random.choice(nn[0])
               
                while nn_index == i:
                    nn_index = random.choice(nn[0])
                    
                dif = T[nn_index] - T[i]
                gap = np.random.uniform(low = 0.0, high = h)
                S[n + i * N, :] = T[i,:] + gap * dif[:]
        
        return S


    def runClassification(self, outputFormat='score', doSubsampling=False, subRate=1.0,
                            doSMOTE=False, pctSMOTE=100, nFolds=10, models=['LR'], topK=.1,):
        

        
        if outputFormat=='score':
            if doSMOTE or doSubsampling:
                print 'Sorry, scoring with subsampling or SMOTE not yet implemented'
                return
            
            for ix,clf in enumerate([clfs[x] for x in models]):
                kf = cross_validation.KFold(len(self.dataset), nFolds, shuffle=True)
                scores = cross_validation.cross_val_score(clf, self.dataset, self.labels, cv=kf)
                print models[ix]+ ' Accuracy: %.2f' % np.mean(scores)
        
        
        elif outputFormat=='summary' or outputFormat=='matrix':
            for ix,clf in enumerate([clfs[x] for x in models]):
               
                y_prediction_results = []; y_smote_prediction_results = []
                y_original_values = []
                
                
                kf = cross_validation.StratifiedKFold(self.labels, n_folds=nFolds)
                for i, (train, test) in enumerate(kf):
                    if doSubsampling:
                    	
                        train = self.subsample(self.dataset,self.labels,train,subRate)
                    if doSMOTE:
                         
                        minority = self.dataset[train][np.where(self.labels[train]==1)]
                        smotted = self.SMOTE(minority, pctSMOTE, 5)
                        X_train_smote = np.vstack((self.dataset[train],smotted))
                        y_train_smote = np.append(self.labels[train],np.ones(len(smotted),dtype=np.int32))
                        
                        y_pred_smote = clf.fit(X_train_smote, y_train_smote).predict(self.dataset[test])
                         
                        y_smote_prediction_results = np.concatenate((y_smote_prediction_results,y_pred_smote),axis=0)
   
                    
		    fitted_clf = clf.fit(self.dataset[train], self.labels[train])
		    
                    y_pred = fitted_clf.predict(self.dataset[test])
                    
                    y_prediction_results = np.concatenate((y_prediction_results,y_pred),axis=0)
                    
                    y_original_values = np.concatenate((y_original_values,self.labels[test]),axis=0)
                
                 
                
                
                if outputFormat=='summary':
                    print '\t\t\t\t\t\t'+models[ix]+ ' Summary Results'
                    cm = classification_report(y_original_values, y_prediction_results,target_names=['Graduated','Did NOT Graduate'])
                    print(str(cm)+'\n')
                    if doSMOTE:
                        print '\t\t\t\t\t\t'+models[ix]+ ' SMOTE Summary Results'
                        cm = classification_report(y_original_values, y_smote_prediction_results,target_names=['Graduated','Did NOT Graduate'])
                        print(str(cm)+'\n')
                    print '----------------------------------------------------------\n'
                
                
                else:
                    print '\t\t\t\t\t'+models[ix]+ ' Confusion Matrix'
                    print '\t\t\t\tGraduated\tDid NOT Graduate'
                    cm = confusion_matrix(y_original_values, y_prediction_results)
                    print 'Graduated\t\t\t%d\t\t%d'% (cm[0][0],cm[0][1])
                    print 'Did NOT Graduate\t%d\t\t%d'% (cm[1][0],cm[1][1])
                    if doSMOTE:
                        print '\n\t\t\t\t'+models[ix]+ ' SMOTE Confusion Matrix'
                        print '\t\t\t\tGraduated\tDid NOT Graduate'
                        cm = confusion_matrix(y_original_values, y_smote_prediction_results)
                        print 'Graduated\t\t\t%d\t\t%d'% (cm[0][0],cm[0][1])
                        print 'Did NOT Graduate\t%d\t\t%d'% (cm[1][0],cm[1][1])
                        
                    print '----------------------------------------------------------\n'
                
        
        elif outputFormat=='roc':
            for ix,clf in enumerate([clfs[x] for x in models]):
                kf = cross_validation.StratifiedKFold(self.labels, n_folds=nFolds)
                mean_tpr = mean_smote_tpr = 0.0
                mean_fpr = mean_smote_fpr = np.linspace(0, 1, 100)
                
                for i, (train, test) in enumerate(kf):
                    if doSubsampling:
                        train = self.subsample(self.dataset,self.labels,train,subRate)
                    if doSMOTE:
                        minority = self.dataset[train][np.where(self.labels[train]==1)]
                        smotted = self.SMOTE(minority, pctSMOTE, 5)
                        X_train = np.vstack((self.dataset[train],smotted))
                        y_train = np.append(self.labels[train],np.ones(len(smotted),dtype=np.int32))
                        probas2_ = clf.fit(X_train, y_train).predict_proba(self.dataset[test])
                        fpr, tpr, thresholds = roc_curve(self.labels[test], probas2_[:, 1])
                        mean_smote_tpr += np.interp(mean_smote_fpr, fpr, tpr)
                        mean_smote_tpr[0] = 0.0

                    
		    fitted_clf = clf.fit(self.dataset[train], self.labels[train])
		    
                    probas_ = fitted_clf.predict_proba(self.dataset[test])
                    
                    fpr, tpr, thresholds = roc_curve(self.labels[test], probas_[:, 1])
                    mean_tpr += np.interp(mean_fpr, fpr, tpr)

                
                pl.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Baseline')

                
                mean_tpr /= len(kf)
                mean_tpr[-1] = 1.0
                mean_auc = auc(mean_fpr, mean_tpr)

                
                pl.plot(mean_fpr, mean_tpr, 'k-',
                        label='Mean ROC (area = %0.2f)' % mean_auc, lw=2)
                        
                
                if doSMOTE:
                    mean_smote_tpr /= len(kf)
                    mean_smote_tpr[-1] = 1.0
                    mean_smote_auc = auc(mean_smote_fpr, mean_smote_tpr)
                    pl.plot(mean_smote_fpr, mean_smote_tpr, 'r-',
                        label='Mean smote ROC (area = %0.2f)' % mean_smote_auc, lw=2)

                pl.xlim([-0.05, 1.05])
                pl.ylim([-0.05, 1.05])
                pl.xlabel('False Positive Rate')
                pl.ylabel('True Positive Rate')
                pl.title(models[ix]+ ' ROC')
                pl.legend(loc="lower right")
                pl.show()
                
        
        elif outputFormat =='prc' or outputFormat =='topk' or outputFormat =='risk':
            for ix,clf in enumerate([clfs[x] for x in models]):
                y_prob = []; y_smote_prob = []
                y_prediction_results = []; y_smote_prediction_results = []
                y_original_values = []; test_indexes = []
            
                kf = cross_validation.StratifiedKFold(self.labels, n_folds=nFolds, shuffle=True)
                mean_pr = mean_smote_pr = 0.0
                mean_rc = mean_smote_rc = np.linspace(0, 1, 100)
                
                for i, (train, test) in enumerate(kf):
                    if doSubsampling:
                        train = self.subsample(self.dataset,self.labels,train,subRate)
                        
                    if doSMOTE:
                        clf2 = clf
                        minority = self.dataset[train][np.where(self.labels[train]==1)]
                        smotted = self.SMOTE(minority, pctSMOTE, 5)
                        X_train = np.vstack((self.dataset[train],smotted))
                        y_train = np.append(self.labels[train],np.ones(len(smotted),dtype=np.int32))
                        clf2.fit(X_train, y_train)
                        probas2_ = clf2.predict_proba(self.dataset[test])
                        y_pred_smote = clf2.predict(self.dataset[test])
                         
                        y_smote_prediction_results = np.concatenate((y_smote_prediction_results,y_pred_smote),axis=0)
                        y_smote_prob = np.concatenate((y_smote_prob,probas2_[:, 1]),axis=0)

                    clf.fit(self.dataset[train], self.labels[train])
                    y_pred = clf.predict(self.dataset[test])
                    y_prediction_results = np.concatenate((y_prediction_results,y_pred),axis=0)
                    test_indexes = np.concatenate((test_indexes,test),axis=0)
                    y_original_values = np.concatenate((y_original_values,self.labels[test]),axis=0)
                    probas_ = clf.predict_proba(self.dataset[test])
                    y_prob = np.concatenate((y_prob,probas_[:, 1]),axis=0)
                    
                
                precision, recall, thresholds = precision_recall_curve(y_original_values, y_prob)
                pr_auc = auc(recall, precision)
                
                        
                if doSMOTE:
                    precision_smote, recall_smote, thresholds_smote = precision_recall_curve(y_original_values, y_smote_prob)
                    pr_auc_smote = auc(recall_smote, precision_smote)

                
                if outputFormat=='prc':
                    pl.plot(recall, precision, color = 'b', label='Precision-Recall curve (area = %0.2f)' % pr_auc)
                    if doSMOTE:
                        pl.plot(recall_smote, precision_smote, color = 'r', label='SMOTE Precision-Recall curve (area = %0.2f)' % pr_auc_smote)
                    pl.xlim([-0.05, 1.05])
                    pl.ylim([-0.05, 1.05])
                    pl.xlabel('Recall')
                    pl.ylabel('Precision')
                    pl.title(models[ix]+ ' Precision-Recall')
                    pl.legend(loc="lower right")
                    pl.show()
                    
                
                elif outputFormat =='risk':
                    test_indexes = test_indexes.astype(int)
                    sort_ix = np.argsort(test_indexes)
                    students_by_risk = self.students[test_indexes]
                    y_prob = ((y_prob[sort_ix])*100).astype(int)
                    probas = np.column_stack((students_by_risk,y_prob))
                    r = int(topK*len(y_original_values))
                    print models[ix]+ ' top ' + str(100*topK) + '%' + ' highest risk'
                    print '--------------------------'
                    print '%-15s %-10s' % ('Student','Risk Score')
                    print '%-15s %-10s' % ('-------','----------')
                    probas = probas[np.argsort(probas[:, 1])[::-1]]
                    for i in range(r):
                        print '%-15s %-10d' % (probas[i][0], probas[i][1])
                    print '\n'
                
                   
                else:
                    ord_prob = np.argsort(y_prob,)[::-1] 
                    r = int(topK*len(y_original_values))
                    print models[ix]+ ' Precision at top ' + str(100*topK) + '%'
                    print np.sum(y_original_values[ord_prob][:r])/r

                    if doSMOTE:
                        ord_prob = np.argsort(y_smote_prob,)[::-1] 
                        print models[ix]+ ' SMOTE Precision at top ' + str(100*topK) + '%'
                        print np.sum(y_original_values[ord_prob][:r])/r
                    print '\n'

