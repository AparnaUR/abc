import classification
import pandas as pd



df = pd.read_csv('../data/simulated_data.csv',index_col=0)


pred = classification.Model(df,'nograd')
while True:
    print "CHOOSE THE CLASSIFIER FOR RISK CALCULATION"
    
    print "0. RF: Random Forest Classifier"
    print "1. ET: ExtraTreesClassifier"
    print "2. AB: AdaBoostClassifier"
    print "3. LR: Logistic Regression"
    print "4. SVM: Support Vector Machine"
    print "5. GB: GradientBoostingClassifier"
    print "6. NB: GaussianNB"
    print "7. DT: DecisionTreeClassifier "
    
    ch=input("Enter the Classifier no:")

    
    print "CHOOSE THE OUTPUT FORMAT"
    
    print "1. RISK"
    print "2. SCORE"
    print "3. SUMMARY"
    print "4. MATRIX"
    print "5. PRECISION RECALL CURVE"
    print "6. ROC"
   
    ch1=input("Enter the Output format: ")

    if ch==0: 
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['RF'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['RF'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['RF'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['RF'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['RF'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['RF'], nFolds=10)
        else:
            print "wrong output format"

    elif ch==1:
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['ET'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['ET'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['ET'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['ET'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['ET'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['ET'], nFolds=10)
        else:
            print "wrong output format"
    
    elif ch==2: 
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['AB'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['AB'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['AB'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['AB'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['AB'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['AB'], nFolds=10)
        else:
            print "wrong output format"    
   
    elif ch==3:  
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['LR'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['LR'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['LR'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['LR'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['LR'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['LR'], nFolds=10)
        else:
            print "wrong output format"    
        
    elif ch==4: 
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['SVM'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['SVM'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['SVM'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['SVM'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['SVM'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['SVM'], nFolds=10)
        else:
            print "wrong output format"
     
       
    elif ch==5:
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['GB'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['GB'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['GB'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['GB'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['GB'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['GB'], nFolds=10)
        else:
            print "wrong output format"
    
    elif  ch==6:
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['NB'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['NB'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['NB'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['NB'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['NB'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['NB'], nFolds=10)
        else:
            print "wrong output format"
    
    elif ch==7:
        if ch1==1:  
            pred.runClassification(outputFormat='risk', models=['DT'], nFolds=10) 
        elif ch1==2:  
            pred.runClassification(outputFormat='score', models=['DT'], nFolds=10)
        elif ch1==3:
            pred.runClassification(outputFormat='summary', models=['DT'], nFolds=10)
        elif ch1==4:
            pred.runClassification(outputFormat='matrix', models=['DT'], nFolds=10)
        elif ch1==5:
            pred.runClassification(outputFormat='prc', models=['DT'], nFolds=10)
        elif ch1==6:
            pred.runClassification(outputFormat='roc', models=['DT'], nFolds=10)
        else:
            print "wrong output format"
   
   
    else:
        print "invalid choice for classifier"

    value=raw_input("Do you want to continue(y/n): ")
    if value=='n':
        break


